<?php

$db_host     = "localhost";
$db_name     = "peoplepr_peopleprohrm";
$db_user     = "peoplepr_peopleprohrm";
$db_password = "Dm)J9.KJo9i&";
$filePath   = 'peoplepro.sql';

$db = new mysqli($db_host, $db_user, $db_password, $db_name);


/* start delete all table from database */
$db->query('SET foreign_key_checks = 0');
if ($result = $db->query("SHOW TABLES")) {
    while($row = $result->fetch_array(MYSQLI_NUM)) {
        $db->query('DROP TABLE IF EXISTS '.$row[0]);
    }
}
$db->query('SET foreign_key_checks = 1');
/* end delete all table from database */

/* start import sql file to database*/
// Temporary variable, used to store current query
$templine = '';
// Read in entire file
$lines = file($filePath);
// Loop through each line
foreach ($lines as $line){
    // Skip it if it's a comment
    if(substr($line, 0, 2) == '--' || $line == ''){
        continue;
    }
    // Add this line to the current segment
    $templine .= $line;
    // If it has a semicolon at the end, it's the end of the query
    if (substr(trim($line), -1, 1) == ';'){
        // Perform the query
        $db->query($templine);                
        // Reset temp variable to empty
        $templine = '';
    }
}
/* end import sql file to database*/
$db->close();
?>

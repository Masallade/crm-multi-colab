<?php

class lc_Envato_Verify {

	private $api_url = 'https://api.envato.com/v3/market';

	function __construct( $api_key ) {
        $this->api_key = $api_key;
	}

	protected function curl( $url ) {
		if ( empty( $url) ) return false;

		$api_key		= $this->api_key;

		$ch = curl_init( $url );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt( $ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; Envato API Wrapper PHP)' );

		$header = array();
		$header[] = 'Content-length: 0';
		$header[] = 'Content-type: application/json';
		$header[] = 'Authorization: Bearer '. $api_key;

		curl_setopt( $ch, CURLOPT_HTTPHEADER, $header );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0);

		$data = curl_exec( $ch );
		curl_getinfo( $ch,CURLINFO_HTTP_CODE );
		curl_close( $ch );

		$response = json_decode( $data, true );
		return $response;
	}

	public function verify_purchase( $purchase_code = '' ) {
		if ( empty( $purchase_code ) ) {
			return false;
		}
		
		$purchase_code = str_replace(' ', '', $purchase_code);

		$purchase_code 	= urlencode( $purchase_code );

		$url = $this->api_url . '/author/sale?code=' . $purchase_code;

	    $response = $this->curl( $url );

    	if ((isset( $response['error'] ) && $response['error'] == '404') || $response['item']['id'] != '48966937') {
    		return false;
    	} else {
            return true;
        }

	}
}

$verify = new lc_Envato_Verify( 'KjK2iwnvmSXUVPyQR3viA0og3U777RVF' );

if(isset($_POST['purchasecode'])) {
	$object = new \stdClass();
	$object->codecheck = $verify->verify_purchase( $_POST['purchasecode']) ? true : false;
// 	$object->codecheck = true;
	if ($object->codecheck) { 
		$object->authorServerURL = "https://peopleprohrmsaas.com/public/peopleprosaas.zip"; 
	}
	$jsondata = json_encode($object);
	echo $jsondata;
}

?>

<!DOCTYPE html>
<html>
<head>
</head>
<body>
<form action="" method="post">
<input type="text" name="purchasecode">
<input type="submit" value="Submit">
</form>
</body>
</html>
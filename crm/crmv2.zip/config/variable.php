<?php

return [

//	'date_format' => '',

	'currency' => 'PKR',
	'currency_format' => 'prefix',
	'account_id' => 1,

];
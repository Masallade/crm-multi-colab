<?php

return array (
    'Do you want to delete ?' => 'መሰረዝ ይፈልጋሉ ?',
    'Payment History' => 'የክፍያ ታሪክ'
);

<?php

return array (
  'failed' => '',
);

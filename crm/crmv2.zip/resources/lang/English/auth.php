<?php

return array (
  'failed' => 'failed',
  'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
);

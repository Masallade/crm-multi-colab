<div class="row">    
    <div class="table-responsive">
        <table id="employee_task-table" class="table ">
            <thead>
            <tr>
                <th>{{trans('file.Title')}}</th>
                <th>{{__('End Date')}}</th>
                <th>{{trans('file.Status')}}</th>
                <th>{{__('Assigned Employees')}}</th>
                <th>{{__('Created By')}}</th>
                <th>{{__('Task Progress')}}</th>
                <th class="not-exported">{{trans('file.action')}}</th>
            </tr>
            </thead>

        </table>
    </div>
</div>
<div class="row">    
    <div class="table-responsive">
        <table id="employee_project-table" class="table ">
            <thead>
            <tr>
                <th>{{__('Project Summary')}}</th>
                <th>{{trans('file.Priority')}}</th>
                <th>{{__('Assigned Employees')}}</th>
                <th>{{trans('file.Client')}}</th>
                <th>{{__('End Date')}}</th>
                <th>{{__('Project Progress')}}</th>
                <th class="not-exported">{{trans('file.action')}}</th>
            </tr>
            </thead>
        </table>
    </div>
</div>
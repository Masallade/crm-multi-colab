<div class="row">    
    <div class="table-responsive">
        <table id="employee_ticket-table" class="table ">
            <thead>
            <tr>
                <th>{{__('Ticket Details')}}</th>
                <th>{{trans('file.Subject')}}</th>
                <th>{{trans('file.Priority')}}</th>
                <th>{{trans('file.Date')}}</th>
                <th class="not-exported">{{trans('file.action')}}</th>
            </tr>
            </thead>

        </table>
    </div>
</div>
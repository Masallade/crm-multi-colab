
<div class="row">
    <div class="table-responsive">
        <table id="employeeRemainingLeaveTable" class="table ">
            <thead>
            <tr>
                <th>{{__('Leave Type')}}</th>
                <th>{{trans('file.Allocated Day')}}</th>
                <th>{{trans('file.Remaining')}}</th>
            </tr>
            </thead>

        </table>
    </div>
</div>

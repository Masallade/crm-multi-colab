
    <script type="text/javascript"
            src="<?php echo asset('vendor/fullcalendar/packages/core/main.js') ?>"></script>

    <script type="text/javascript"
            src="<?php echo asset('vendor/fullcalendar/packages/daygrid/main.js') ?>"></script>

    <script type="text/javascript"
            src="<?php echo asset('vendor/fullcalendar/packages/interaction/main.js') ?>"></script>

    <script type="text/javascript"
            src="<?php echo asset('vendor/fullcalendar/packages/timegrid/main.js') ?>"></script>

    <script type="text/javascript"
            src="<?php echo asset('vendor/fullcalendar/packages/list/main.js') ?>"></script>




{{-- <script type="text/javascript" src="{{ asset('vendor/fullcalendar/packages/core/main.js') }}"></script>
<script type="text/javascript" src="{{ asset('vendor/fullcalendar/packages/daygrid/main.js') }}"></script>
<script type="text/javascript" src="{{ asset('vendor/fullcalendar/packages/interaction/main.js') }}"></script>
<script type="text/javascript" src="{{ asset('vendor/fullcalendar/packages/timegrid/main.js') }}"></script>
<script type="text/javascript" src="{{ asset('vendor/fullcalendar/packages/list/main.js') }}"></script> --}}

<div class="container-fluid">
    <div class="card mb-0">
        <div class="card-body">
            <h3 class="card-title">{{__('Add Appraisal Section')}}</h3>
            <form method="post" action="{{ route('getNewAppraisalType') }}" id="appraisal_section_form" class="form-horizontal">
                @csrf

                <div id="sections-container">
                    <div class="section-group mb-4">
                        <div class="form-group">
                            <label for="section_name">{{__('Appraisal Section Name')}}</label>
                            <input type="text" name="section_name[]" class="form-control"
                                   placeholder="{{__('Enter Appraisal Section Name')}}">
                        </div>

                        <div class="form-group d-flex align-items-center">
                            <label class="mr-3">{{__('Section Weightage (%)')}}</label>
                            <div class="d-flex align-items-center">
                                <input type="number" name="section_weightage[]" class="form-control section-weightage w-25"
                                       placeholder="0" min="1" max="100">
                                <span class="ml-2">%</span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>{{__('Indicators')}}</label>
                            <div class="indicators-container">
                                <div class="input-group mb-2 indicator-group">
                                    <input type="text" name="indicators[0][]" class="form-control" placeholder="{{__('Enter Indicator')}}">
                                    <div class="input-group-append">
                                        <button type="button" class="btn btn-danger remove-indicator">{{__('Remove')}}</button>
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-primary add-indicator">{{__('Add Indicator')}}</button>
                        </div>
                        <button type="button" class="btn btn-danger remove-section">{{__('Remove Section')}}</button>
                    </div>
                </div>

                <div class="form-group mt-3">
                    <p id="weightage-left" class="font-weight-bold text-danger">{{__('Weightage Left:')}} <span>100%</span></p>
                </div>

                <button type="button" id="add-section" class="btn btn-secondary mt-3">{{__('Add Section')}}</button>

                <div class="form-group mt-3">
                    <button type="submit" class="btn btn-success" id="submit-form">{{__('Submit')}}</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    .form-group label {
        font-weight: bold;
    }

    .section-group {
        border: 1px solid #ddd;
        padding: 15px;
        border-radius: 8px;
        background-color: #f9f9f9;
    }

    .btn {
        border-radius: 5px;
    }

    .btn-primary {
        background-color: #007bff;
        border: none;
    }

    .btn-danger {
        background-color: #dc3545;
        border: none;
    }

    .btn-secondary {
        background-color: #6c757d;
        border: none;
    }

    .input-group .form-control {
        border-radius: 4px;
    }

    .font-weight-bold {
        font-size: 1.1rem;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const sectionsContainer = document.getElementById('sections-container');
        const addSectionButton = document.getElementById('add-section');
        const weightageLeftDisplay = document.getElementById('weightage-left').querySelector('span');
        const submitButton = document.getElementById('submit-form');

        let sectionIndex = 0;
        let weightageLeft = 100;

        // Add a new section
        addSectionButton.addEventListener('click', () => {
            if (weightageLeft <= 0) {
                alert("No weightage left to add a new section!");
                return;
            }

            sectionIndex++;
            const sectionGroup = document.createElement('div');
            sectionGroup.classList.add('section-group', 'mb-4');

            sectionGroup.innerHTML = `
                <div class="form-group">
                    <label for="section_name">{{__('Appraisal Section Name')}}</label>
                    <input type="text" name="section_name[]" class="form-control"
                           placeholder="{{__('Enter Appraisal Section Name')}}">
                </div>

                <div class="form-group d-flex align-items-center">
                    <label class="mr-3">{{__('Section Weightage (%)')}}</label>
                    <div class="d-flex align-items-center">
                        <input type="number" name="section_weightage[]" class="form-control section-weightage w-25"
                               placeholder="0" min="1" max="100">
                        <span class="ml-2">%</span>
                    </div>
                </div>

                <div class="form-group">
                    <label>{{__('Indicators')}}</label>
                    <div class="indicators-container">
                        <div class="input-group mb-2 indicator-group">
                            <input type="text" name="indicators[${sectionIndex}][]" class="form-control" placeholder="{{__('Enter Indicator')}}">
                            <div class="input-group-append">
                                <button type="button" class="btn btn-danger remove-indicator">{{__('Remove')}}</button>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="btn btn-primary add-indicator">{{__('Add Indicator')}}</button>
                </div>
                <button type="button" class="btn btn-danger remove-section">{{__('Remove Section')}}</button>
            `;

            sectionsContainer.appendChild(sectionGroup);
            attachSectionEventListeners(sectionGroup);
        });

        function attachSectionEventListeners(section) {
            const weightageInput = section.querySelector('.section-weightage');
            weightageInput.addEventListener('input', handleWeightageChange);

            section.querySelector('.remove-section').addEventListener('click', () => {
                const weightageValue = parseInt(weightageInput.value) || 0;
                weightageLeft += weightageValue;
                updateWeightageDisplay();
                section.remove();
            });

            const addIndicatorButton = section.querySelector('.add-indicator');
            const indicatorsContainer = section.querySelector('.indicators-container');
            addIndicatorButton.addEventListener('click', () => {
                const indicatorGroup = document.createElement('div');
                indicatorGroup.classList.add('input-group', 'mb-2', 'indicator-group');

                indicatorGroup.innerHTML = `
                    <input type="text" name="indicators[${sectionIndex}][]" class="form-control" placeholder="{{__('Enter Indicator')}}">
                    <div class="input-group-append">
                        <button type="button" class="btn btn-danger remove-indicator">{{__('Remove')}}</button>
                    </div>
                `;

                indicatorsContainer.appendChild(indicatorGroup);
                indicatorGroup.querySelector('.remove-indicator').addEventListener('click', () => {
                    indicatorGroup.remove();
                });
            });
        }

        function handleWeightageChange(e) {
            const currentInput = e.target;
            const newValue = parseInt(currentInput.value) || 0;

            if (newValue < 0 || newValue > weightageLeft) {
                alert(`Weightage must be between 0 and ${weightageLeft}%`);
                currentInput.value = '';
                return;
            }

            const previousValue = parseInt(currentInput.getAttribute('data-prev-value')) || 0;
            weightageLeft += previousValue - newValue;

            if (weightageLeft < 0) weightageLeft = 0;

            currentInput.setAttribute('data-prev-value', newValue);
            updateWeightageDisplay();
        }

        function updateWeightageDisplay() {
            weightageLeftDisplay.textContent = `${weightageLeft}%`;
            addSectionButton.disabled = weightageLeft <= 0;
        }

        // Prevent form submission if weightage is not 0
        submitButton.addEventListener('click', (e) => {
            if (weightageLeft !== 0) {
                e.preventDefault();
                alert("Remaining weightage must be 0 to submit the form!");
            }
        });

        // Attach event listeners to the initial section
        document.querySelectorAll('.section-group').forEach(section => {
            attachSectionEventListeners(section);
        });
    });
</script>
